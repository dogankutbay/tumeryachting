## Playground

Use this pen to test and develop new features of Material Design for Bootstrap:

http://codepen.io/FezVrasta/pen/ihmea

It already includes every needed dependency and is based on the latest version of the theme.

## Grunt

**Grunt!** Ok... when you edit something please run `grunt` to compile CSS and copy stuff in the correct folders. Thanks!

## License

Please be sure to read the [license](LICENSE.md) before contributing to this project. This software is share source, this means that the author keep every rights on every edit on this source.
